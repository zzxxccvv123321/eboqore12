let currentQuestion = 0;
let score = 0;
let selectedSet = [];
let difficulty = '';

const questions = {
  easy: [
    {
      q: "ما هو الرقم التالي في السلسلة: 2، 4، 6؟",
      a: ["8", "9", "7"],
      c: 0,
      type: "math"
    },
    {
      q: "ما هو الحيوان المختلف: قطة، كلب، برتقال؟",
      a: ["قطة", "برتقال", "كلب"],
      c: 1,
      type: "logic"
    },
    {
      q: "كم عدد حروف كلمة 'سيارة'؟",
      a: ["5", "6", "4"],
      c: 0,
      type: "focus"
    }
  ],
  medium: [
    {
      q: "إذا كان أحمد أكبر من خالد بـ5 سنوات، وخالد عمره 10، كم عمر أحمد؟",
      a: ["15", "12", "13"],
      c: 0,
      type: "math"
    },
    {
      q: "من هو الغريب: ربيع، خريف، شتاء، موز؟",
      a: ["موز", "خريف", "شتاء"],
      c: 0,
      type: "logic"
    },
    {
      q: "كم مرة تنطبق عقارب الساعة في اليوم؟",
      a: ["22", "24", "12"],
      c: 0,
      type: "info"
    }
  ],
  hard: [
    {
      q: "رجل لديه 4 بنات، كل بنت لها أخ واحد. كم عدد أولاده؟",
      a: ["5", "4", "1"],
      c: 0,
      type: "logic"
    },
    {
      q: "في غرفة بها مرآة، سقط ريشة فوقها. كم وزن الانعكاس؟",
      a: ["لا شيء", "1 غرام", "0.5 غرام"],
      c: 0,
      type: "focus"
    },
    {
      q: "إذا قمت بعكس الرقم 86، ما الناتج؟",
      a: ["68", "98", "لا شيء"],
      c: 1,
      type: "math"
    }
  ]
};

function startTest(level) {
  difficulty = level;
  selectedSet = [...questions[level]].sort(() => 0.5 - Math.random()).slice(0, 10);
  currentQuestion = 0;
  score = 0;
  document.getElementById("main").style.display = "none";
  document.getElementById("quiz").style.display = "block";
  loadQuestion();
}

function loadQuestion() {
  let q = selectedSet[currentQuestion];
  document.getElementById("questionText").innerText = q.q;
  document.getElementById("answers").innerHTML = "";
  q.a.forEach((ans, i) => {
    let btn = document.createElement("button");
    btn.innerText = ans;
    btn.onclick = () => checkAnswer(i);
    document.getElementById("answers").appendChild(btn);
  });
}

function checkAnswer(selected) {
  if (selected === selectedSet[currentQuestion].c) score++;
  currentQuestion++;
  if (currentQuestion < selectedSet.length) {
    loadQuestion();
  } else {
    showResult();
  }
}

function showResult() {
  document.getElementById("quiz").style.display = "none";
  document.getElementById("result").style.display = "block";
  document.getElementById("scoreText").innerText = `لقد حصلت على ${score} من 10`;

  let wrong = selectedSet.filter((q, i) => {
    return i < score ? false : true;
  });

  let types = wrong.map(q => q.type);
  let freq = {};
  types.forEach(t => freq[t] = (freq[t] || 0) + 1);

  let weakest = Object.entries(freq).sort((a, b) => b[1] - a[1])[0];

  let advice = '';
  if (!weakest) {
    advice = "أداء ممتاز! استمر على هذا المستوى.";
  } else {
    switch (weakest[0]) {
      case "math":
        advice = "يبدو أنك ضعيف في الحسابات الذهنية. حاول حل مسائل رياضية بسيطة يوميًا.";
        break;
      case "logic":
        advice = "تفكيرك المنطقي يحتاج إلى تدريب أكثر. جرب ألعاب الألغاز والمنطق.";
        break;
      case "focus":
        advice = "انتباهك للتفاصيل منخفض. قم بتمارين تركيز يومية وابتعد عن التشتيت.";
        break;
      case "info":
        advice = "معلوماتك العامة بحاجة إلى تطوير. اقرأ أكثر في مواضيع متنوعة.";
        break;
      default:
        advice = "حاول مراجعة أخطائك لتحسين مستواك.";
    }
  }

  document.getElementById("adviceText").innerText = advice;
}